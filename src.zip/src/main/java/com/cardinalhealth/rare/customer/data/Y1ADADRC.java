package com.cardinalhealth.rare.customer.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Y1ADADRC{
    @JsonProperty("ADDRNUMBER")
    public String aDDRNUMBER;
    @JsonProperty("FAX_NUMBER")
    public String fAX_NUMBER;
    @JsonProperty("STR_SUPPL1")
    public String sTR_SUPPL1;
    @JsonProperty("STR_SUPPL2")
    public String sTR_SUPPL2;
    @JsonProperty("STR_SUPPL3")
    public String sTR_SUPPL3;
    @JsonProperty("TEL_NUMBER")
    public String tEL_NUMBER;
}
