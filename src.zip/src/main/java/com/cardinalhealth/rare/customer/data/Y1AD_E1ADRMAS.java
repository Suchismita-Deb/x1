package com.cardinalhealth.rare.customer.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Y1AD_E1ADRMAS {
    @JsonProperty("Y1AD_ADRC")
    public List<Y1AD_ADRC> Y1AD_ADRC;
}
