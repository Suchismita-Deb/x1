package com.cardinalhealth.rare.customer.service;

import com.fasterxml.jackson.core.JsonProcessingException;

public interface ProcessingService {

    public void processRecord(String value) throws JsonProcessingException;

}
