package com.cardinalhealth.rare.customer.service.impl;

import com.cardinalhealth.rare.customer.service.ProcessingService;
import com.cardinalhealth.rare.customer.data.MasterData;
import com.cardinalhealth.rare.customer.entity.CustomerMaster;
import com.cardinalhealth.rare.customer.repository.CustomerMasterRepo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;

@Service
@Slf4j
public class ProcessingServiceImpl implements ProcessingService {


    @Autowired
    CustomerMasterRepo customermasterrepo;

    @Value("${update.enable:true}")
    private boolean updateEnabled;

    @Override
    public void processRecord(String value) throws JsonProcessingException {
        try {
        log.debug("Start: processRecord - Processing record with value: {}", value);
        MasterData masterData;

        masterData = new ObjectMapper().readValue(value, MasterData.class);
        // to avoid stale data where we are getting material number as null
        if (null == masterData.getE1KNA1M().getKUNNR()) {
            log.debug("KUNNR Filed is Empty, Skipping the record");
            return;
        }

            mapDataToEntity(masterData);
        }
        catch (Exception e){
            log.error("Exception occurred in processRecord() method. Throwing... Error={}", e.getMessage());
        }
    }

    public void mapDataToEntity(MasterData customerdata) {
        DateTimeFormatter format=DateTimeFormatter.ofPattern("yyyyMMdd");
        CustomerMaster rds = new CustomerMaster();
        rds.setCustomerUID("3PL-" + customerdata.getE1KNA1M().getKUNNR());
        rds.setCustomerNumber(customerdata.getE1KNA1M().getKUNNR());
        rds.setSourceErpId("3PL");

        if( (null != customerdata.getE1KNA1M().getY1BP_IDNUMBER()) && (!CollectionUtils.isEmpty(customerdata.getE1KNA1M().getY1BP_IDNUMBER())) ) {
            for (int i = 0; i < customerdata.getE1KNA1M().getY1BP_IDNUMBER().size(); i++) {
                if (customerdata.getE1KNA1M().getY1BP_IDNUMBER().get(i).getTYPE().equals("ZDEALI")) {
                    rds.setDeaLicenseNumber(customerdata.getE1KNA1M().getY1BP_IDNUMBER().get(i).getIDNUMBER());
                    LocalDate date = LocalDate.parse(customerdata.getE1KNA1M().getY1BP_IDNUMBER().get(i).getVALID_DATE_TO(),format);
                    Timestamp timestamp=Timestamp.valueOf(date.atStartOfDay());
                    rds.setRegistrationExpireDate(timestamp);
//                    rds.setRegistrationExpireDate(customerdata.getE1KNA1M().getY1BP_IDNUMBER().get(i).getVALID_DATE_TO());
                    rds.setRegion(customerdata.getE1KNA1M().getY1BP_IDNUMBER().get(i).getREGION());
                }
                if (customerdata.getE1KNA1M().getY1BP_IDNUMBER().get(i).getTYPE().equals("ZSTBPL")) {
                    rds.setStatePharmacyLicenseNumber(customerdata.getE1KNA1M().getY1BP_IDNUMBER().get(i).getIDNUMBER());
                }
                if (customerdata.getE1KNA1M().getY1BP_IDNUMBER().get(i).getTYPE().equals("ZNPIID")) {
                    rds.setNcpdpNumber(customerdata.getE1KNA1M().getY1BP_IDNUMBER().get(i).getIDNUMBER());
                }
            }
        }

            rds.setCustomerClassTrade(customerdata.getE1KNA1M().getKUKLA());

        if( (null != customerdata.getE1KNA1M().getNAME1()) && !(customerdata.getE1KNA1M().getNAME1().equals("")) ) {
            rds.setNameLine1(customerdata.getE1KNA1M().getNAME1());
        }
        if( (null != customerdata.getE1KNA1M().getNAME2()) && !(customerdata.getE1KNA1M().getNAME2().equals("")) ) {
            rds.setNameLine2(customerdata.getE1KNA1M().getNAME2());
        }

        if( (null != customerdata.getE1KNA1M().getNAME3()) && !(customerdata.getE1KNA1M().getNAME3().equals("")) ) {
                rds.setNameLine3(customerdata.getE1KNA1M().getNAME3());
            }
        if( (null != customerdata.getE1KNA1M().getNAME4()) && !(customerdata.getE1KNA1M().getNAME4().equals("")) ) {
            rds.setNameLine4(customerdata.getE1KNA1M().getNAME4());
        }

        if( (null != customerdata.getE1KNA1M().getY1AD_E1ADRMAS()) && (!CollectionUtils.isEmpty(customerdata.getE1KNA1M().getY1AD_E1ADRMAS())) )
        {
            if(null != customerdata.getE1KNA1M().getY1AD_E1ADRMAS().get(0).getY1AD_ADRC() &&
                        !CollectionUtils.isEmpty(customerdata.getE1KNA1M().getY1AD_E1ADRMAS().get(0).getY1AD_ADRC()))
            {
                rds.setAddressNumber(customerdata.getE1KNA1M().getY1AD_E1ADRMAS().get(0).getY1AD_ADRC().get(0).getADDRNUMBER());
                rds.setStreet2(customerdata.getE1KNA1M().getY1AD_E1ADRMAS().get(0).getY1AD_ADRC().get(0).getSTR_SUPPL1());
                rds.setStreet3(customerdata.getE1KNA1M().getY1AD_E1ADRMAS().get(0).getY1AD_ADRC().get(0).getSTR_SUPPL2());
                rds.setStreet4(customerdata.getE1KNA1M().getY1AD_E1ADRMAS().get(0).getY1AD_ADRC().get(0).getSTR_SUPPL3());
                rds.setPhone(customerdata.getE1KNA1M().getY1AD_E1ADRMAS().get(0).getY1AD_ADRC().get(0).getTEL_NUMBER());
                rds.setFax(customerdata.getE1KNA1M().getY1AD_E1ADRMAS().get(0).getY1AD_ADRC().get(0).getFAX_NUMBER());
            }
        }

        rds.setRegion(customerdata.getE1KNA1M().getREGIO());
        rds.setPostalCode(customerdata.getE1KNA1M().getPSTLZ());
        rds.setCityName(customerdata.getE1KNA1M().getORT01());
        rds.setPoboxCity(customerdata.getE1KNA1M().getPFORT());
        rds.setCityCode(customerdata.getE1KNA1M().getCITYC());
        rds.setPlant(customerdata.getE1KNA1M().getWERKS());
        rds.setAltPayerAcctNum(customerdata.getE1KNA1M().getKNRZA());
        rds.setAcctGroup(customerdata.getE1KNA1M().getKTOKD());
        rds.setCustomerClass(customerdata.getE1KNA1M().getKUKLA());
        rds.setTradingPartnerCompanyId(customerdata.getE1KNA1M().getVBUND());

        if( (null != customerdata.getE1KNA1M().getE1KNA11()) && !(customerdata.getE1KNA1M().getE1KNA11().equals("")) ) {
            rds.setRepName(customerdata.getE1KNA1M().getE1KNA11().getJ_1KFREPRE());
            rds.setPersonName1(customerdata.getE1KNA1M().getE1KNA11().getPSON1());
            rds.setPersonName2(customerdata.getE1KNA1M().getE1KNA11().getPSON2());
            rds.setPersonName3(customerdata.getE1KNA1M().getE1KNA11().getPSON3());
            rds.setStateCode(customerdata.getE1KNA1M().getE1KNA11().getUF());
        }

        if( (null != customerdata.getE1KNA1M().getE1KNVVM()) && (!CollectionUtils.isEmpty(customerdata.getE1KNA1M().getE1KNVVM())) ) {

            rds.setOurAccountNumberAtCustomer(customerdata.getE1KNA1M().getE1KNVVM().get(0).getEIKTO());//which array to take
            rds.setSalesOrgId(customerdata.getE1KNA1M().getE1KNVVM().get(0).getVKORG());
        }

        rds.setRowAddUserId("kafkauser");
        rds.setRowUpdateUserId("kafkauser");
        rds.setRowAddStp(Timestamp.from(Instant.now()));
        rds.setRowUpdateStp(Timestamp.from(Instant.now()));
        customermasterrepo.save(rds);
        log.info("Record "+customerdata.getE1KNA1M().getKUNNR()+" has been saved to Database");

    }

}