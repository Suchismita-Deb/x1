package com.cardinalhealth.rare.customer.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Y1BPIDNUMBER{
    @JsonProperty("TYPE")
    public String tYPE;
    @JsonProperty("IDNUMBER")
    public String iDNUMBER;
    @JsonProperty("IDNUMBER_GUID")
    public String iDNUMBER_GUID;
    @JsonProperty("REGION")
    public String rEGION;
    @JsonProperty("VALID_DATE_TO")
    public String vALID_DATE_TO;
}

