package com.cardinalhealth.rare.customer.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Immutable;

import java.sql.Timestamp;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "customer_master", schema = "customer")
public class CustomerMaster {

    @Id
    @Column(name = "customer_uid")
    String customerUID;

    @Column(name = "customer_number")
    String customerNumber;

    @Column (name = "source_erp_id")
    String sourceErpId;

    @Column (name = "dea_license_number")
    String deaLicenseNumber;

    @Column(name = "state_pharmacy_license_number")
    String statePharmacyLicenseNumber;

    @Column(name = "ncpdp_number")
    String ncpdpNumber;

    @Column(name = "registration_expire_date")
    Timestamp registrationExpireDate;

    @Column(name = "region")
    String region;

    @Column(name = "customer_class_trade")
    String customerClassTrade;

    @Column(name = "name_1")
    String nameLine1;

    @Column(name = "name_2")
    String nameLine2;

    @Column(name = "name_3")
    String nameLine3;

    @Column(name = "name_4")
    String nameLine4;

    @Column(name = "address_number")
    String addressNumber;

    @Column(name = "street_2")
    String street2;

    @Column(name = "street_3")
    String street3;

    @Column(name = "street_4")
    String street4;

    @Column(name = "postal_code")
    String postalCode;

    @Column(name = "city_name")
    String cityName;

    @Column(name = "pobox_city")
    String poboxCity;

    @Column(name = "city_code")
    String cityCode;

    @Column(name = "state_code")
    String stateCode;

    @Column(name = "phone")
    String phone;

    @Column(name = "fax")
    String fax;

    @Column(name = "plant")
    String plant;

    @Column(name = "distribution_channel")
    String distribution_channel;

    @Column(name = "alt_payer_acct_num")
    String altPayerAcctNum;

    @Column(name = "acct_group")
    String acctGroup;

    @Column(name = "customer_class")
    String customerClass;

    @Column(name = "trading_partner_company_id")
    String tradingPartnerCompanyId;

    @Column(name = "rep_name")
    String repName;

    @Column(name = "person_name1")
    String personName1;

    @Column(name = "person_name2")
    String personName2;

    @Column(name = "person_name3")
    String personName3;

    @Column(name = "our_account_number_at_customer")
    String ourAccountNumberAtCustomer;

    @Column(name = "business_partner_id")
    Character businessPartnerId;

    @Column(name = "business_partner_guid")
    String businessPartnerGuid;


    @Column(name = "long_name3")
    String longName3;


    @Column(name = "sales_org_id")
    String salesOrgId;

    @Column(name = "row_add_user_id")
    String rowAddUserId;

    @Column(name = "row_update_user_id")
    String rowUpdateUserId;

    @Column(name = "row_add_stp")
    Timestamp rowAddStp;

    @Column(name = "row_update_stp")
    Timestamp rowUpdateStp;
}
