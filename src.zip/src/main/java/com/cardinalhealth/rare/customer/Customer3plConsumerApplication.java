package com.cardinalhealth.rare.customer;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
//import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.time.LocalDateTime;
import java.time.ZoneId;

@SpringBootApplication
@ComponentScan("com.**")
@EnableRetry

@EnableEncryptableProperties
@EnableScheduling
@Slf4j
public class Customer3plConsumerApplication {
	public static void main(String[] args) {

		log.info("Application started at : '{}'", LocalDateTime.now(ZoneId.systemDefault()));
		SpringApplication.run(Customer3plConsumerApplication.class, args);


	}
}