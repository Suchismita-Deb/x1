package com.cardinalhealth.rare.customer.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Y1AD_ADRC {
    @JsonProperty("ADDRNUMBER")
    public String aDDRNUMBER;
    @JsonProperty("STR_SUPPL1")
    public String sTR_SUPPL1;
    @JsonProperty("STR_SUPPL2")
    public String sTR_SUPPL2;
    @JsonProperty("STR_SUPPL3")
    public String sTR_SUPPL3;
    @JsonProperty("TEL_NUMBER")
    public String tEL_NUMBER            ;
    @JsonProperty("FAX_NUMBER")
    public String fAX_NUMBER;
}

