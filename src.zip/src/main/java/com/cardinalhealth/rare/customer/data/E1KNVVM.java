package com.cardinalhealth.rare.customer.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class E1KNVVM{
    @JsonProperty("VKORG")
    public String vKORG;
    @JsonProperty("EIKTO")
    public String eIKTO;
}
