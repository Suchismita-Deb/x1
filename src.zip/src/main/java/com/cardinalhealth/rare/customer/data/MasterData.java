package com.cardinalhealth.rare.customer.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class MasterData {

    @JsonProperty("E1KNA1M")
    public E1KNA1M e1KNA1M;


}

