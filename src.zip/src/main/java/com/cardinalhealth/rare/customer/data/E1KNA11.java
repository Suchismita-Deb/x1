package com.cardinalhealth.rare.customer.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class E1KNA11{
    @JsonProperty("J_1KFREPRE")
    public String j_1KFREPRE;
    @JsonProperty("PSON1")
    public String pSON1;
    @JsonProperty("PSON2")
    public String pSON2;
    @JsonProperty("PSON3")
    public String pSON3;
    @JsonProperty("UF")
    public String uF;
}
