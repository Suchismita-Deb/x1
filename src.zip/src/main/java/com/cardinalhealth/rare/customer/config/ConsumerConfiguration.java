package com.cardinalhealth.rare.customer.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.*;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.backoff.BackOff;
import org.springframework.util.backoff.FixedBackOff;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Configuration
@Slf4j
public class ConsumerConfiguration {

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${spring.kafka.properties.security.protocol}")
    private String securityProtocol;

    @Value("${spring.kafka.properties.sasl.mechanism}")
    private String saslMechanism;

    @Value("${spring.kafka.properties.sasl.jaas.config}")
    private String saslJaasConfig;

    @Value("${spring.kafka.consumer.group-id}")
    private String groupId;

    @Value("${spring.kafka.consumer.key-deserializer}")
    private String keyDeserializer;

    @Value("${spring.kafka.consumer.value-deserializer}")
    private String valueDeserializer;

    @Value("${spring.kafka.consumer.enable-auto-commit}")
    private boolean enableAutoCommit;

    @Value("${spring.kafka.consumer.auto-offset-reset}")
    private String autoOffsetReset;

    @Value("${spring.kafka.properties.allow.auto.create.topics}")
    private String allowAutoCreateTopics;

    @Value("${spring.kafka.properties.auto.register.schemas}")
    private String autoRegisterSchemas;

    @Value("${spring.kafka.backoff.interval}")
    private Long interval;

    @Value("${spring.kafka.backoff.max-attempts}")
    private Long maxAttempts;

    @Value("${spring.application.name}")
    private String applicationName;



    @Bean
    public Map<String, Object> kafkaConfig() {
        Map<String, Object> props = new HashMap<>();

        // Kafka Cluster/Confluent Cloud connection configs
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put("security.protocol", securityProtocol);
        props.put("sasl.jaas.config", saslJaasConfig);
        props.put("sasl.mechanism", saslMechanism);

        return props;
    }

    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        Map<String, Object> props = new HashMap<>(kafkaConfig());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, keyDeserializer);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, valueDeserializer);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, enableAutoCommit);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
        props.put(ConsumerConfig.ALLOW_AUTO_CREATE_TOPICS_CONFIG, allowAutoCreateTopics);

        return new DefaultKafkaConsumerFactory<>(props);
    }

    @Bean
    public ProducerFactory<String, String> producerFactory() {
        Map<String, Object> props = new HashMap<>(kafkaConfig());
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        return new DefaultKafkaProducerFactory<>(props);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> containerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        factory.getContainerProperties().setDeliveryAttemptHeader(true);
        return factory;
    }

    /**
     * The DefaultErrorHandler provides a blocking retry mechanism for messages that fail due to some error. After
     * retrying a configured number of times, the lambda expression will execute to perform any error handling.
     * Additional reading: <a href="https://www.baeldung.com/spring-retry-kafka-consumer">...</a>
     * @return - DefaultErrorHandler object
     */
    @Bean
    public DefaultErrorHandler errorHandler(KafkaOperations<String, String> template) {
        BackOff fixedBackOff = new FixedBackOff(interval, maxAttempts);
        DefaultErrorHandler errorHandler = new DefaultErrorHandler((consumerRecord, e) -> {
            // Ensure this topic has been created beforehand (and write permissions are granted to the API key, per environment)
            String dltName = consumerRecord.topic() + "_3PL_DLQ";
            log.info("All attempts to consume message key '{}' have been exhausted. Producing to Dead Letter Topic: '{}'", consumerRecord.key(), dltName);
            template.send(dltName, (String) consumerRecord.key() + consumerRecord.value(),  "Error Message: " + e.getMessage());
            log.info("Successfully produced message with key '{}' to Dead Letter Topic '{}'", consumerRecord.key(), dltName);
        }, fixedBackOff);
        errorHandler.setCommitRecovered(true); // Needed so that after the error handler block executes, the original message is acknowledged/committed

        // Uncomment this method below to add additional exceptions that you do NOT want to retry (See docs for current default exceptions)
        // errorHandler.addNotRetryableExceptions();

        return errorHandler;
    }

    @Bean("dltProducer")
    public KafkaTemplate<String, String> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }


    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder){
        return builder.build();
    }
}