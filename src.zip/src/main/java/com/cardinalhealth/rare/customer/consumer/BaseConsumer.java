package com.cardinalhealth.rare.customer.consumer;


import com.cardinalhealth.rare.customer.service.ProcessingService;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.core.convert.ConversionException;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.serializer.DeserializationException;
import org.springframework.messaging.converter.MessageConversionException;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.invocation.MethodArgumentResolutionException;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class BaseConsumer {
    final ProcessingService processingService;

    public BaseConsumer(ProcessingService processingService) {
        this.processingService = processingService;
    }

    @KafkaListener(topics = {"${topicName}"}, containerFactory = "containerFactory")
    public void consume(ConsumerRecord<String, String> record, Acknowledgment ack, @Header(value = KafkaHeaders.DELIVERY_ATTEMPT) int attemptNumber) throws JsonProcessingException {
        try {
            log.info("RECEIVED MESSAGE :: Key: '{}' :: Topic: '{}' Offset: '{}' Partition: '{}' :: Attempt Number: '{}'",
                    record.key(), record.topic(), record.offset(), record.partition(), attemptNumber);
            processingService.processRecord(record.value());
            ack.acknowledge();
            log.info("SUCCESSFULLY PROCESSED MESSAGE :: Key: '{}' :: Topic: '{}' Offset: '{}' Partition: '{}' :: Attempt Number: '{}'",
                    record.key(), record.topic(), record.offset(), record.partition(), attemptNumber);
        } catch (DeserializationException | MessageConversionException | ConversionException |
                 MethodArgumentResolutionException | ClassCastException | JsonProcessingException e) {
            // These exceptions are non-retryable; log a message then throw to container so error handler picks it up
            log.error("Non-retryable exception occurred during processing :: Key: '{}' :: Topic: '{}' Offset: '{}' Partition: '{}' :: Attempt Number: '{}'",
                    record.key(), record.topic(), record.offset(), record.partition(), attemptNumber);
            throw e;
        } catch (Exception e) {
            // Any other exceptions will be retried
            log.error("Retryable exception occurred during processing :: Key: '{}' :: Topic: '{}' Offset: '{}' Partition: '{}' :: Attempt Number: '{}'",
                    record.key(), record.topic(), record.offset(), record.partition(), attemptNumber);
            throw e; // Need to throw to the container so the error handler will pick it up for retries
        }
    }
}