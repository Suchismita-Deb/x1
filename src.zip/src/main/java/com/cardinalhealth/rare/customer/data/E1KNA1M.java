package com.cardinalhealth.rare.customer.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class E1KNA1M{
    @JsonProperty("KUNNR")
    public String kUNNR;
    @JsonProperty("KNRZA")
    public String kNRZA;
    @JsonProperty("KTOKD")
    public String kTOKD;
    @JsonProperty("KUKLA")
    public String kUKLA;
    @JsonProperty("NAME1")
    public String nAME1;
    @JsonProperty("NAME2")
    public String nAME2;
    @JsonProperty("NAME3")
    public String nAME3;
    @JsonProperty("NAME4")
    public String nAME4;
    @JsonProperty("ORT01")
    public String oRT01;
    @JsonProperty("PSTLZ")
    public String pSTLZ;
    @JsonProperty("REGIO")
    public String rEGIO;
    @JsonProperty("CITYC")
    public String cITYC;
    @JsonProperty("VBUND")
    public String vBUND;
    @JsonProperty("PFORT")
    public String pFORT;
    @JsonProperty("WERKS")
    public String wERKS;
    @JsonProperty("Y1BP_IDNUMBER")
    public List<Y1BPIDNUMBER> y1BP_IDNUMBER;
    @JsonProperty("Y1AD_E1ADRMAS")
    public List<Y1AD_E1ADRMAS> y1AD_E1ADRMAS;
    @JsonProperty("E1KNA11")
    public E1KNA11 e1KNA11;
    @JsonProperty("E1KNVVM")
    public List<E1KNVVM> e1KNVVM;

}

