package com.cardinalhealth.rare.customer.com.cardinalhealth.rare.customer.consumer;


import com.cardinalhealth.rare.customer.config.ConsumerConfiguration;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.*;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.test.util.ReflectionTestUtils;


import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

public class ConsumerConfigurationTest {

    @Test
    public void testKafkaConfig(){
        ConsumerConfiguration consumerConfiguration = new ConsumerConfiguration();
        ReflectionTestUtils.setField(consumerConfiguration, "bootstrapServers", "abcd");
        ReflectionTestUtils.setField(consumerConfiguration, "securityProtocol", "xyz");
        ReflectionTestUtils.setField(consumerConfiguration, "saslJaasConfig", "ghij");
        ReflectionTestUtils.setField(consumerConfiguration, "saslMechanism", "http");
        assertNotNull(consumerConfiguration.kafkaConfig());
    }

    @Test
    public void testDefaultErrorHandler(){
        ConsumerConfiguration consumerConfiguration = new ConsumerConfiguration();
        KafkaOperations<String,String>template = mock(KafkaOperations.class);
        ReflectionTestUtils.setField(consumerConfiguration, "interval", Long.valueOf("2000"));
        ReflectionTestUtils.setField(consumerConfiguration, "maxAttempts", Long.valueOf("3"));
        assertThat(consumerConfiguration.errorHandler(template)).isNotEqualTo(null);
    }

    @Test
    public void testConsumerFactoryCustomer(){
        ConsumerConfiguration consumerConfiguration = new ConsumerConfiguration();
        ReflectionTestUtils.setField(consumerConfiguration, "groupId", "abcd");
        ReflectionTestUtils.setField(consumerConfiguration, "keyDeserializer", "xyz");
        ReflectionTestUtils.setField(consumerConfiguration, "valueDeserializer", "ghij");
        ReflectionTestUtils.setField(consumerConfiguration, "enableAutoCommit", true);
        ReflectionTestUtils.setField(consumerConfiguration, "autoOffsetReset", "http");
        ReflectionTestUtils.setField(consumerConfiguration, "allowAutoCreateTopics", "http");

        assertThrows(NullPointerException.class, () -> {

            consumerConfiguration.consumerFactory();
        });
    }

    @Test
    public void testProducerFactory(){
        ConsumerConfiguration consumerConfiguration = new ConsumerConfiguration();
        assertThrows(Exception.class, () -> {

            consumerConfiguration.producerFactory();
        });
    }

    @Test
    @DisplayName("Testing Container Factory Customer")
    public void testContainerFactoryCustomer(){
        ConsumerConfiguration consumerConfiguration = new ConsumerConfiguration();
        ConsumerConfiguration consumerConfiguration1 = mock(ConsumerConfiguration.class);
        KafkaOperations<String,String>template = mock(KafkaOperations.class);
        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory();
        DefaultErrorHandler defaultErrorHandler = mock(DefaultErrorHandler.class);
        ConsumerFactory consumerFactory = mock(ConsumerFactory.class);
        Mockito.doReturn(consumerFactory).when(consumerConfiguration1).consumerFactory();
        Mockito.doReturn(defaultErrorHandler).when(consumerConfiguration1).errorHandler(template);
        assertThrows(Exception.class, () -> {
            consumerConfiguration.containerFactory();
        });
    }

    @Test
    @DisplayName("Testing KafkaTemplate")
    public void testKafkaTemplate(){
        ConsumerConfiguration consumerConfiguration = Mockito.spy(ConsumerConfiguration.class);
        DefaultKafkaProducerFactory defaultKafkaProducerFactory = mock(DefaultKafkaProducerFactory.class);
        Mockito.doReturn(defaultKafkaProducerFactory).when(consumerConfiguration).producerFactory();
        assertThat(consumerConfiguration.kafkaTemplate()).isNotEqualTo(null);
    }

}