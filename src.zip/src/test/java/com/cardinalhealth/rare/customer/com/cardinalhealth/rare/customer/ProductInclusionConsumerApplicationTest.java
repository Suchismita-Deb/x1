//package com.cardinalhealth.product.inclusion.com.cardinalhealth.rare.customer;

//@SpringBootTest
//public class ProductInclusionConsumerApplicationTest {

//    @Test
//    void contextLoads() {}
//}
