package com.cardinalhealth.rare.customer.com.cardinalhealth.rare.customer.consumer;


import com.cardinalhealth.rare.customer.data.*;
import com.cardinalhealth.rare.customer.repository.CustomerMasterRepo;
import com.cardinalhealth.rare.customer.service.ProcessingService;
import com.cardinalhealth.rare.customer.service.impl.ProcessingServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class ProcessingServiceTest {
    @Mock
    CustomerMasterRepo customerMasterRepo;

    @InjectMocks
    ProcessingServiceImpl processingService;

    @Mock
    E1KNA1M e1KNA1M = new E1KNA1M();
    E1KNA11 e1KNA11= new E1KNA11();
    List<E1KNVVM> e1KNVVM = new ArrayList<>();
    Y1AD_ADRC y1AD_ADRC = new Y1AD_ADRC();
    List<Y1BPIDNUMBER> y1BPIDNUMBER = new ArrayList<>();

    @BeforeEach
    public void setup() {
        ReflectionTestUtils.setField(processingService, "updateEnabled", true);
    }

    public void setObject(){
        E1KNVVM e1KNVVm = new E1KNVVM();
        Y1BPIDNUMBER y1BPIDNUMBEr = new Y1BPIDNUMBER();

        List<E1KNVVM> e1KNVVMList = new ArrayList<>();
        E1KNVVM e1KNVVM1 = new E1KNVVM();
        e1KNVVM1.setEIKTO("test");
        e1KNVVM1.setVKORG("test");
        e1KNVVMList.add(e1KNVVm);

        e1KNA1M.setKUNNR("3PL-1234");
        e1KNA1M.setKNRZA("abc");
        e1KNA1M.setKTOKD("test");
        e1KNA1M.setKUKLA("test");
        e1KNA1M.setNAME1("test");
        e1KNA1M.setNAME2("test");
        e1KNA1M.setNAME3("test");
        e1KNA1M.setNAME4("test");
        e1KNA1M.setE1KNVVM(e1KNVVMList);
        e1KNA11.setJ_1KFREPRE("abc");

    }

    @Test
    public void processRecordTest() throws JsonProcessingException {
        String kafkaMessage = "{\"EDI_DC40\":{\"TABNAM\":\"EDI_DC40\",\"MANDT\":\"200\",\"DOCNUM\":\"0000000000270102\",\"DOCREL\":\"757\",\"STATUS\":\"03\",\"DIRECT\":\"1\",\"OUTMOD\":\"2\",\"IDOCTYP\":\"DEBMAS08\",\"CIMTYP\":\"YEDEBMAS08_EXTN\",\"MESTYP\":\"DEBMAS\",\"SNDPOR\":\"SAPDE3\",\"SNDPRT\":\"LS\",\"SNDPRN\":\"DE3CLNT200\",\"RCVPOR\":\"ACI_IDOC\",\"RCVPRT\":\"LS\",\"RCVPRN\":\"LS_ASAPIO\",\"CREDAT\":\"20250617\",\"CRETIM\":\"213958\",\"SERIAL\":\"20250617213930\"},\"E1KNA1M\":{\"MSGFN\":\"004\",\"KUNNR\":\"BM7182\",\"ANRED\":\"\",\"AUFSD\":\"\",\"BAHNE\":\"\",\"BAHNS\":\"\",\"BBBNR\":\"1234456\",\"BBSNR\":\"78909\",\"BEGRU\":\"\",\"BRSCH\":\"BM\",\"BUBKZ\":\"1\",\"DATLT\":\"\",\"FAKSD\":\"\",\"FISKN\":\"\",\"KNRZA\":\"\",\"KONZS\":\"\",\"KTOKD\":\"ZSHP\",\"KUKLA\":\"WS\",\"LAND1\":\"US\",\"LIFNR\":\"\",\"LIFSD\":\"\",\"LOCCO\":\"\",\"LOEVM\":\"\",\"NAME1\":\"TEXAS CHILDRENS HOSP 340B\",\"NAME2\":\"abc\",\"NAME3\":\"abc\",\"NAME4\":\"abc\",\"NIELS\":\"\",\"ORT01\":\"HOUSTON\",\"ORT02\":\"\",\"PFACH\":\"\",\"PSTL2\":\"\",\"PSTLZ\":\"77030\",\"REGIO\":\"FL\",\"COUNC\":\"\",\"CITYC\":\"\",\"RPMKR\":\"\",\"SORTL\":\"\",\"SPERR\":\"\",\"SPRAS\":\"E\",\"STCD1\":\"\",\"STCD2\":\"\",\"STKZA\":\"\",\"STKZU\":\"\",\"STRAS\":\"6621 FANNIN ST\",\"TELBX\":\"\",\"TELF1\":\"832-824-5270\",\"TELF2\":\"\",\"TELFX\":\"\",\"TELTX\":\"\",\"TELX1\":\"\",\"LZONE\":\"\",\"XZEMP\":\"\",\"VBUND\":\"\",\"STCEG\":\"\",\"GFORM\":\"\",\"BRAN1\":\"\",\"BRAN2\":\"\",\"BRAN3\":\"\",\"BRAN4\":\"\",\"BRAN5\":\"\",\"UMJAH\":\"0000\",\"UWAER\":\"\",\"JMZAH\":\"000000\",\"JMJAH\":\"0000\",\"KATR1\":\"\",\"KATR2\":\"\",\"KATR3\":\"\",\"KATR4\":\"\",\"KATR5\":\"\",\"KATR6\":\"\",\"KATR7\":\"\",\"KATR8\":\"\",\"KATR9\":\"\",\"KATR10\":\"\",\"STKZN\":\"\",\"UMSA1\":\"0\",\"TXJCD\":\"\",\"PERIV\":\"\",\"KTOCD\":\"\",\"PFORT\":\"\",\"DTAMS\":\"\",\"DTAWS\":\"\",\"HZUOR\":\"00\",\"CIVVE\":\"\",\"MILVE\":\"\",\"SPRAS_ISO\":\"EN\",\"FITYP\":\"\",\"STCDT\":\"\",\"STCD3\":\"\",\"STCD4\":\"\",\"XICMS\":\"\",\"XXIPI\":\"\",\"XSUBT\":\"\",\"CFOPC\":\"\",\"TXLW1\":\"\",\"TXLW2\":\"\",\"CCC01\":\"\",\"CCC02\":\"\",\"CCC03\":\"\",\"CCC04\":\"\",\"CASSD\":\"\",\"KDKG1\":\"\",\"KDKG2\":\"\",\"KDKG3\":\"\",\"KDKG4\":\"\",\"KDKG5\":\"\",\"NODEL\":\"\",\"XSUB2\":\"\",\"WERKS\":\"\",\"Y1BP_IDNUMBER\":[{\"PARTNER\":\"BM7182\",\"TYPE\":\"Z00003\",\"IDNUMBER\":\"BM\",\"INSTITUTE\":\"\",\"ENTRY_DATE\":\"00000000\",\"VALID_DATE_FROM\":\"00\",\"VALID_DATE_TO\":\"20241212\",\"COUNTRY\":\"000\",\"REGION\":\"000\",\"IDNUMBER_GUID\":\"\"},{\"PARTNER\":\"BM7182\",\"TYPE\":\"ZDEALI\",\"IDNUMBER\":\"SHIPTO_DEA\",\"INSTITUTE\":\"\",\"ENTRY_DATE\":\"00000000\",\"VALID_DATE_FROM\":\"00\",\"VALID_DATE_TO\":\"20241212\",\"COUNTRY\":\"000\",\"REGION\":\"000\",\"IDNUMBER_GUID\":\"\"},{\"PARTNER\":\"BM7182\",\"TYPE\":\"ZSTBPL\",\"IDNUMBER\":\"SHIPTO_SBP\",\"INSTITUTE\":\"\",\"ENTRY_DATE\":\"00000000\",\"VALID_DATE_FROM\":\"00\",\"VALID_DATE_TO\":\"00000000\",\"COUNTRY\":\"000\",\"REGION\":\"000\",\"IDNUMBER_GUID\":\"\"}],\"Y1AD_E1ADRMAS\":[{\"OBJ_TYPE\":\"KNA1\",\"OBJ_ID\":\"BM7182\",\"CONTEXT\":\"0001\",\"IV_CHECK_ADDRESS\":\"X\",\"IV_TIME_DEPENDENT_COMM_DATA\":\"X\",\"Y1AD_ADRC\":[{\"ADDRNUMBER\":\"0000027644\",\"DEFLT_COMM\":\"\",\"FAX_NUMBER\":\"\",\"STR_SUPPL1\":\"\",\"STR_SUPPL2\":\"\",\"STR_SUPPL3\":\"\",\"TAXJURCODE\":\"\",\"TEL_NUMBER\":\"832-824-5270\",\"TIME_ZONE\":\"CST\"}],\"Y1AD_ADR2\":[{\"ADDRNUMBER\":\"0000027644\",\"CONSNUMBER\":\"001\",\"COUNTRY\":\"US\",\"DFT_RECEIV\":\"\",\"FLGDEFAULT\":\"X\",\"FLG_NOUSE\":\"\",\"HOME_FLAG\":\"X\",\"R3_USER\":\"3\",\"TELNR_CALL\":\"8328245270\",\"TELNR_LONG\":\"+18328245270\",\"TEL_EXTENS\":\"\",\"TEL_NUMBER\":\"832-824-5270\",\"VALID_FROM\":\"\",\"VALID_TO\":\"\"}]}],\"Y1E1KNA1M\":[{\"NAME1\":\"TEXAS CHILDRENS HOSP 340B\",\"BU_SORT2\":\"\"}],\"E1KNA11\":{\"KNURL\":\"\",\"J_1KFREPRE\":\"abc\",\"J_1KFTBUS\":\"\",\"J_1KFTIND\":\"\",\"PSOIS\":\"\",\"PSON1\":\"\",\"PSON2\":\"\",\"PSON3\":\"\",\"PSOVN\":\"\",\"PSOTL\":\"\",\"PSOO1\":\"\",\"PSOO2\":\"\",\"PSOO3\":\"\",\"PSOO4\":\"\",\"PSOO5\":\"\",\"STCD5\":\"\",\"SUFRAMA\":\"\",\"RG\":\"\",\"EXP\":\"\",\"UF\":\"\",\"RGDATE\":\"00000000\",\"RIC\":\"00000000000\",\"RNE\":\"\",\"RNEDATE\":\"00000000\",\"CNAE\":\"\",\"LEGALNAT\":\"0000\",\"CRTN\":\"\",\"ICMSTAXPAY\":\"\",\"INDTYP\":\"\",\"TDT\":\"\",\"COMSIZE\":\"\",\"DECREGPC\":\"\",\"CVP_XBLCK\":\"\",\"STCD6\":\"\"},\"E1KNA1G1\":{\"J_1IEXCD\":\"\",\"J_1IEXRN\":\"\",\"J_1IEXRG\":\"\",\"J_1IEXDI\":\"\",\"J_1IEXCO\":\"\",\"J_1ICSTNO\":\"\",\"J_1ILSTNO\":\"\",\"J_1IPANNO\":\"\",\"J_1IEXCICU\":\"\",\"J_1ISERN\":\"\",\"J_1IPANREF\":\"\",\"GST_TDS\":\"\"}},\"E1IDOCENHANCEMENT\":[{\"IDENTIFIER\":\"CFD_S_KNA1_IDOC_EX_1\",\"DATA\":\"91484293509C1FE092F873B399575D50\uFEFF<?xml version=\\\"1.0\\\" encoding=\\\"utf-16\\\"?><asx:abap xmlns:asx=\\\"http://www.sap.com/abapxml\\\" version=\\\"1.0\\\"><asx:values><KEY>BM7182</KEY><DATA><KNA1_EEW_CUST/><RULE_EXCLUSION/></DATA></asx:values></asx:abap>\"}]}";
        processingService.processRecord(kafkaMessage);
    }

    @Test
    public void processRecordTest3() throws JsonProcessingException {
        String kafkaMessage = "{\"EDI_DC40\":{\"TABNAM\":\"EDI_DC40\",\"MANDT\":\"200\",\"DOCNUM\":\"0000000000270102\",\"DOCREL\":\"757\",\"STATUS\":\"03\",\"DIRECT\":\"1\",\"OUTMOD\":\"2\",\"IDOCTYP\":\"DEBMAS08\",\"CIMTYP\":\"YEDEBMAS08_EXTN\",\"MESTYP\":\"DEBMAS\",\"SNDPOR\":\"SAPDE3\",\"SNDPRT\":\"LS\",\"SNDPRN\":\"DE3CLNT200\",\"RCVPOR\":\"ACI_IDOC\",\"RCVPRT\":\"LS\",\"RCVPRN\":\"LS_ASAPIO\",\"CREDAT\":\"20250617\",\"CRETIM\":\"213958\",\"SERIAL\":\"20250617213930\"},\"E1KNA1M\":{\"MSGFN\":\"004\",\"KUNNR\":\"BM7182\",\"ANRED\":\"\",\"AUFSD\":\"\",\"BAHNE\":\"\",\"BAHNS\":\"\",\"BBBNR\":\"1234456\",\"BBSNR\":\"78909\",\"BEGRU\":\"\",\"BRSCH\":\"BM\",\"BUBKZ\":\"1\",\"DATLT\":\"\",\"FAKSD\":\"\",\"FISKN\":\"\",\"KNRZA\":\"\",\"KONZS\":\"\",\"KTOKD\":\"ZSHP\",\"KUKLA\":\"WS\",\"LAND1\":\"US\",\"LIFNR\":\"\",\"LIFSD\":\"\",\"LOCCO\":\"\",\"LOEVM\":\"\",\"NAME1\":\"TEXAS CHILDRENS HOSP 340B\",\"NAME2\":\"abc\",\"NAME3\":\"abc\",\"NAME4\":\"abc\",\"NIELS\":\"\",\"ORT01\":\"HOUSTON\",\"ORT02\":\"\",\"PFACH\":\"\",\"PSTL2\":\"\",\"PSTLZ\":\"77030\",\"REGIO\":\"FL\",\"COUNC\":\"\",\"CITYC\":\"\",\"RPMKR\":\"\",\"SORTL\":\"\",\"SPERR\":\"\",\"SPRAS\":\"E\",\"STCD1\":\"\",\"STCD2\":\"\",\"STKZA\":\"\",\"STKZU\":\"\",\"STRAS\":\"6621 FANNIN ST\",\"TELBX\":\"\",\"TELF1\":\"832-824-5270\",\"TELF2\":\"\",\"TELFX\":\"\",\"TELTX\":\"\",\"TELX1\":\"\",\"LZONE\":\"\",\"XZEMP\":\"\",\"VBUND\":\"\",\"STCEG\":\"\",\"GFORM\":\"\",\"BRAN1\":\"\",\"BRAN2\":\"\",\"BRAN3\":\"\",\"BRAN4\":\"\",\"BRAN5\":\"\",\"UMJAH\":\"0000\",\"UWAER\":\"\",\"JMZAH\":\"000000\",\"JMJAH\":\"0000\",\"KATR1\":\"\",\"KATR2\":\"\",\"KATR3\":\"\",\"KATR4\":\"\",\"KATR5\":\"\",\"KATR6\":\"\",\"KATR7\":\"\",\"KATR8\":\"\",\"KATR9\":\"\",\"KATR10\":\"\",\"STKZN\":\"\",\"UMSA1\":\"0\",\"TXJCD\":\"\",\"PERIV\":\"\",\"KTOCD\":\"\",\"PFORT\":\"\",\"DTAMS\":\"\",\"DTAWS\":\"\",\"HZUOR\":\"00\",\"CIVVE\":\"\",\"MILVE\":\"\",\"SPRAS_ISO\":\"EN\",\"FITYP\":\"\",\"STCDT\":\"\",\"STCD3\":\"\",\"STCD4\":\"\",\"XICMS\":\"\",\"XXIPI\":\"\",\"XSUBT\":\"\",\"CFOPC\":\"\",\"TXLW1\":\"\",\"TXLW2\":\"\",\"CCC01\":\"\",\"CCC02\":\"\",\"CCC03\":\"\",\"CCC04\":\"\",\"CASSD\":\"\",\"KDKG1\":\"\",\"KDKG2\":\"\",\"KDKG3\":\"\",\"KDKG4\":\"\",\"KDKG5\":\"\",\"NODEL\":\"\",\"XSUB2\":\"\",\"WERKS\":\"\",\"Y1BP_IDNUMBER\":[{\"PARTNER\":\"BM7182\",\"TYPE\":\"Z00003\",\"IDNUMBER\":\"BM\",\"INSTITUTE\":\"\",\"ENTRY_DATE\":\"00000000\",\"VALID_DATE_FROM\":\"00\",\"VALID_DATE_TO\":\"20241212\",\"COUNTRY\":\"000\",\"REGION\":\"000\",\"IDNUMBER_GUID\":\"\"},{\"PARTNER\":\"BM7182\",\"TYPE\":\"ZDEALI\",\"IDNUMBER\":\"SHIPTO_DEA\",\"INSTITUTE\":\"\",\"ENTRY_DATE\":\"00000000\",\"VALID_DATE_FROM\":\"00\",\"VALID_DATE_TO\":\"20241212\",\"COUNTRY\":\"000\",\"REGION\":\"000\",\"IDNUMBER_GUID\":\"\"},{\"PARTNER\":\"BM7182\",\"TYPE\":\"ZNPIID\",\"IDNUMBER\":\"SHIPTO_SBP\",\"INSTITUTE\":\"\",\"ENTRY_DATE\":\"00000000\",\"VALID_DATE_FROM\":\"00\",\"VALID_DATE_TO\":\"00000000\",\"COUNTRY\":\"000\",\"REGION\":\"000\",\"IDNUMBER_GUID\":\"\"}],\"Y1AD_E1ADRMAS\":[{\"OBJ_TYPE\":\"KNA1\",\"OBJ_ID\":\"BM7182\",\"CONTEXT\":\"0001\",\"IV_CHECK_ADDRESS\":\"X\",\"IV_TIME_DEPENDENT_COMM_DATA\":\"X\",\"Y1AD_ADRC\":[{\"ADDRNUMBER\":\"0000027644\",\"DEFLT_COMM\":\"\",\"FAX_NUMBER\":\"\",\"STR_SUPPL1\":\"\",\"STR_SUPPL2\":\"\",\"STR_SUPPL3\":\"\",\"TAXJURCODE\":\"\",\"TEL_NUMBER\":\"832-824-5270\",\"TIME_ZONE\":\"CST\"}],\"Y1AD_ADR2\":[{\"ADDRNUMBER\":\"0000027644\",\"CONSNUMBER\":\"001\",\"COUNTRY\":\"US\",\"DFT_RECEIV\":\"\",\"FLGDEFAULT\":\"X\",\"FLG_NOUSE\":\"\",\"HOME_FLAG\":\"X\",\"R3_USER\":\"3\",\"TELNR_CALL\":\"8328245270\",\"TELNR_LONG\":\"+18328245270\",\"TEL_EXTENS\":\"\",\"TEL_NUMBER\":\"832-824-5270\",\"VALID_FROM\":\"\",\"VALID_TO\":\"\"}]}],\"Y1E1KNA1M\":[{\"NAME1\":\"TEXAS CHILDRENS HOSP 340B\",\"BU_SORT2\":\"\"}],\"E1KNA11\":{\"KNURL\":\"\",\"J_1KFREPRE\":\"abc\",\"J_1KFTBUS\":\"\",\"J_1KFTIND\":\"\",\"PSOIS\":\"\",\"PSON1\":\"\",\"PSON2\":\"\",\"PSON3\":\"\",\"PSOVN\":\"\",\"PSOTL\":\"\",\"PSOO1\":\"\",\"PSOO2\":\"\",\"PSOO3\":\"\",\"PSOO4\":\"\",\"PSOO5\":\"\",\"STCD5\":\"\",\"SUFRAMA\":\"\",\"RG\":\"\",\"EXP\":\"\",\"UF\":\"\",\"RGDATE\":\"00000000\",\"RIC\":\"00000000000\",\"RNE\":\"\",\"RNEDATE\":\"00000000\",\"CNAE\":\"\",\"LEGALNAT\":\"0000\",\"CRTN\":\"\",\"ICMSTAXPAY\":\"\",\"INDTYP\":\"\",\"TDT\":\"\",\"COMSIZE\":\"\",\"DECREGPC\":\"\",\"CVP_XBLCK\":\"\",\"STCD6\":\"\"},\"E1KNA1G1\":{\"J_1IEXCD\":\"\",\"J_1IEXRN\":\"\",\"J_1IEXRG\":\"\",\"J_1IEXDI\":\"\",\"J_1IEXCO\":\"\",\"J_1ICSTNO\":\"\",\"J_1ILSTNO\":\"\",\"J_1IPANNO\":\"\",\"J_1IEXCICU\":\"\",\"J_1ISERN\":\"\",\"J_1IPANREF\":\"\",\"GST_TDS\":\"\"}},\"E1IDOCENHANCEMENT\":[{\"IDENTIFIER\":\"CFD_S_KNA1_IDOC_EX_1\",\"DATA\":\"91484293509C1FE092F873B399575D50\uFEFF<?xml version=\\\"1.0\\\" encoding=\\\"utf-16\\\"?><asx:abap xmlns:asx=\\\"http://www.sap.com/abapxml\\\" version=\\\"1.0\\\"><asx:values><KEY>BM7182</KEY><DATA><KNA1_EEW_CUST/><RULE_EXCLUSION/></DATA></asx:values></asx:abap>\"}]}";
        processingService.processRecord(kafkaMessage);
    }

    @Test
    public void processRecordTest4() throws JsonProcessingException {
        String kafkaMessage = "{\"EDI_DC40\":{\"TABNAM\":\"EDI_DC40\",\"MANDT\":\"200\",\"DOCNUM\":\"0000000000271652\",\"DOCREL\":\"757\",\"STATUS\":\"03\",\"DIRECT\":\"1\",\"OUTMOD\":\"2\",\"IDOCTYP\":\"DEBMAS08\",\"CIMTYP\":\"YEDEBMAS08_EXTN\",\"MESTYP\":\"DEBMAS\",\"SNDPOR\":\"SAPDE3\",\"SNDPRT\":\"LS\",\"SNDPRN\":\"DE3CLNT200\",\"RCVPOR\":\"ACI_IDOC\",\"RCVPRT\":\"LS\",\"RCVPRN\":\"LS_ASAPIO\",\"CREDAT\":\"20250710\",\"CRETIM\":\"090037\",\"SERIAL\":\"20250710090024\"},\"E1KNA1M\":{\"MSGFN\":\"018\",\"KUNNR\":\"OT1000\",\"ANRED\":\"\",\"AUFSD\":\"\",\"BAHNE\":\"\",\"BAHNS\":\"\",\"BBBNR\":\"0000000\",\"BBSNR\":\"00000\",\"BEGRU\":\"\",\"BRSCH\":\"OT\",\"BUBKZ\":\"0\",\"DATLT\":\"\",\"FAKSD\":\"\",\"FISKN\":\"\",\"KNRZA\":\"\",\"KONZS\":\"\",\"KTOKD\":\"ZSOL\",\"KUKLA\":\"WS\",\"LAND1\":\"AU\",\"LIFNR\":\"\",\"LIFSD\":\"\",\"LOCCO\":\"\",\"LOEVM\":\"\",\"NAME1\":\"AMERISOURCEBERGEN\",\"NAME2\":\"\",\"NAME3\":\"\",\"NAME4\":\"\",\"NIELS\":\"\",\"ORT01\":\"LITTLEISLAND\",\"ORT02\":\"\",\"PFACH\":\"\",\"PSTL2\":\"\",\"PSTLZ\":\"T45NF24\",\"REGIO\":\"NSW\",\"COUNC\":\"\",\"CITYC\":\"\",\"RPMKR\":\"\",\"SORTL\":\"\",\"SPERR\":\"\",\"SPRAS\":\"E\",\"STCD1\":\"\",\"STCD2\":\"\",\"STKZA\":\"\",\"STKZU\":\"\",\"STRAS\":\"8EASTGATEAVENUE\",\"TELBX\":\"\",\"TELF1\":\"\",\"TELF2\":\"\",\"TELFX\":\"\",\"TELTX\":\"\",\"TELX1\":\"\",\"LZONE\":\"\",\"XZEMP\":\"\",\"VBUND\":\"\",\"STCEG\":\"\",\"GFORM\":\"\",\"BRAN1\":\"\",\"BRAN2\":\"\",\"BRAN3\":\"\",\"BRAN4\":\"\",\"BRAN5\":\"\",\"UMJAH\":\"0000\",\"UWAER\":\"\",\"JMZAH\":\"000000\",\"JMJAH\":\"0000\",\"KATR1\":\"\",\"KATR2\":\"\",\"KATR3\":\"\",\"KATR4\":\"\",\"KATR5\":\"\",\"KATR6\":\"WHO\",\"KATR7\":\"\",\"KATR8\":\"\",\"KATR9\":\"\",\"KATR10\":\"\",\"STKZN\":\"\",\"UMSA1\":\"0\",\"TXJCD\":\"\",\"PERIV\":\"\",\"KTOCD\":\"\",\"PFORT\":\"\",\"DTAMS\":\"\",\"DTAWS\":\"\",\"HZUOR\":\"00\",\"CIVVE\":\"\",\"MILVE\":\"\",\"SPRAS_ISO\":\"EN\",\"FITYP\":\"\",\"STCDT\":\"\",\"STCD3\":\"\",\"STCD4\":\"\",\"XICMS\":\"\",\"XXIPI\":\"\",\"XSUBT\":\"\",\"CFOPC\":\"\",\"TXLW1\":\"\",\"TXLW2\":\"\",\"CCC01\":\"\",\"CCC02\":\"\",\"CCC03\":\"\",\"CCC04\":\"\",\"CASSD\":\"\",\"KDKG1\":\"\",\"KDKG2\":\"\",\"KDKG3\":\"\",\"KDKG4\":\"\",\"KDKG5\":\"\",\"NODEL\":\"\",\"XSUB2\":\"\",\"WERKS\":\"\",\"Y1BP_IDNUMBER\":[{\"PARTNER\":\"OT1000\",\"TYPE\":\"Z00003\",\"IDNUMBER\":\"OT\",\"INSTITUTE\":\"\",\"ENTRY_DATE\":\"00000000\",\"VALID_DATE_FROM\":\"00\",\"VALID_DATE_TO\":\"00000000\",\"COUNTRY\":\"000\",\"REGION\":\"000\",\"IDNUMBER_GUID\":\"\"}],\"Y1AD_E1ADRMAS\":[{\"OBJ_TYPE\":\"KNA1\",\"OBJ_ID\":\"OT1000\",\"CONTEXT\":\"0001\",\"IV_CHECK_ADDRESS\":\"X\",\"IV_TIME_DEPENDENT_COMM_DATA\":\"X\",\"Y1AD_ADRC\":[{\"ADDRNUMBER\":\"0000027608\",\"DEFLT_COMM\":\"\",\"FAX_NUMBER\":\"\",\"STR_SUPPL1\":\"\",\"STR_SUPPL2\":\"\",\"STR_SUPPL3\":\"\",\"TAXJURCODE\":\"\",\"TEL_NUMBER\":\"\",\"TIME_ZONE\":\"AUSNSW\"}]}],\"Y1E1KNA1M\":[{\"NAME1\":\"AMERISOURCEBERGEN\",\"BU_SORT2\":\"\"}],\"E1KNA11\":{\"KNURL\":\"\",\"J_1KFREPRE\":\"\",\"J_1KFTBUS\":\"\",\"J_1KFTIND\":\"\",\"PSOIS\":\"\",\"PSON1\":\"\",\"PSON2\":\"\",\"PSON3\":\"\",\"PSOVN\":\"\",\"PSOTL\":\"\",\"PSOO1\":\"\",\"PSOO2\":\"\",\"PSOO3\":\"\",\"PSOO4\":\"\",\"PSOO5\":\"\",\"STCD5\":\"\",\"SUFRAMA\":\"\",\"RG\":\"\",\"EXP\":\"\",\"UF\":\"\",\"RGDATE\":\"00000000\",\"RIC\":\"00000000000\",\"RNE\":\"\",\"RNEDATE\":\"00000000\",\"CNAE\":\"\",\"LEGALNAT\":\"0000\",\"CRTN\":\"\",\"ICMSTAXPAY\":\"\",\"INDTYP\":\"\",\"TDT\":\"\",\"COMSIZE\":\"\",\"DECREGPC\":\"\",\"CVP_XBLCK\":\"\",\"STCD6\":\"\"},\"E1KNA1G1\":{\"J_1IEXCD\":\"\",\"J_1IEXRN\":\"\",\"J_1IEXRG\":\"\",\"J_1IEXDI\":\"\",\"J_1IEXCO\":\"\",\"J_1ICSTNO\":\"\",\"J_1ILSTNO\":\"\",\"J_1IPANNO\":\"\",\"J_1IEXCICU\":\"\",\"J_1ISERN\":\"\",\"J_1IPANREF\":\"\",\"GST_TDS\":\"\"},\"E1KNVVM\":[{\"MSGFN\":\"004\",\"VKORG\":\"1700\",\"VTWEG\":\"10\",\"SPART\":\"00\",\"BEGRU\":\"\",\"LOEVM\":\"\",\"VERSG\":\"\",\"AUFSD\":\"ZD\",\"KALKS\":\"0\",\"KDGRP\":\"\",\"BZIRK\":\"\",\"KONDA\":\"01\",\"PLTYP\":\"\",\"AWAHR\":\"100\",\"INCO1\":\"\",\"INCO2\":\"\",\"LIFSD\":\"\",\"AUTLF\":\"\",\"ANTLF\":\"0\",\"KZTLF\":\"\",\"KZAZU\":\"X\",\"CHSPL\":\"\",\"LPRIO\":\"00\",\"EIKTO\":\"\",\"VSBED\":\"\",\"FAKSD\":\"\",\"MRNKZ\":\"\",\"PERFK\":\"\",\"PERRL\":\"\",\"WAERS\":\"USD\",\"KTGRD\":\"\",\"ZTERM\":\"\",\"VWERK\":\"\",\"VKGRP\":\"\",\"VKBUR\":\"OT\",\"VSORT\":\"\",\"KVGR1\":\"\",\"KVGR2\":\"\",\"KVGR3\":\"\",\"KVGR4\":\"\",\"KVGR5\":\"\",\"BOKRE\":\"\",\"KURST\":\"\",\"PRFRE\":\"\",\"KLABC\":\"\",\"KABSS\":\"\",\"KKBER\":\"\",\"CASSD\":\"\",\"RDOFF\":\"\",\"AGREL\":\"\",\"MEGRU\":\"\",\"UEBTO\":\"0.0\",\"UNTTO\":\"0.0\",\"UEBTK\":\"\",\"PVKSM\":\"\",\"PODKZ\":\"\",\"PODTG\":\"0\",\"BLIND\":\"\",\"CARRIER_NOTIF\":\"\",\"CVP_XBLCK_V\":\"\",\"INCOV\":\"\",\"INCO2_L\":\"\",\"INCO3_L\":\"\",\"KALKS_NEW\":\"01\"}],\"E1KNB1M\":[{\"MSGFN\":\"004\",\"BUKRS\":\"OT\",\"SPERR\":\"X\",\"LOEVM\":\"\",\"ZUAWA\":\"\",\"BUSAB\":\"\",\"AKONT\":\"\",\"BEGRU\":\"\",\"KNRZE\":\"\",\"KNRZB\":\"\",\"ZAMIM\":\"\",\"ZAMIV\":\"\",\"ZAMIR\":\"\",\"ZAMIB\":\"\",\"ZAMIO\":\"\",\"ZWELS\":\"\",\"XVERR\":\"\",\"ZAHLS\":\"\",\"ZTERM\":\"0006\",\"WAKON\":\"\",\"VZSKZ\":\"\",\"ZINDT\":\"00000000\",\"ZINRT\":\"00\",\"EIKTO\":\"\",\"ZSABE\":\"\",\"KVERM\":\"\",\"FDGRV\":\"\",\"VRBKZ\":\"\",\"VLIBB\":\"0\",\"VRSZL\":\"0\",\"VRSPR\":\"0\",\"VRSNR\":\"\",\"VERDT\":\"00000000\",\"PERKZ\":\"\",\"XDEZV\":\"\",\"XAUSZ\":\"\",\"WEBTR\":\"0\",\"REMIT\":\"\",\"DATLZ\":\"00000000\",\"XZVER\":\"\",\"TOGRU\":\"\",\"KULTG\":\"0\",\"HBKID\":\"\",\"XPORE\":\"\",\"BLNKZ\":\"\",\"ALTKN\":\"\",\"ZGRUP\":\"\",\"URLID\":\"\",\"MGRUP\":\"\",\"LOCKB\":\"\",\"UZAWE\":\"\",\"EKVBD\":\"\",\"SREGL\":\"\",\"XEDIP\":\"\",\"FRGRP\":\"\",\"VRSDG\":\"\",\"TLFXS\":\"\",\"PERNR\":\"00000000\",\"INTAD\":\"\",\"GUZTE\":\"\",\"GRICD\":\"\",\"GRIDT\":\"\",\"WBRSL\":\"\",\"NODEL\":\"\",\"TLFNS\":\"\",\"CESSION_KZ\":\"\",\"GMVKZD\":\"\",\"AVSND\":\"\",\"SMTP_ADDR\":\"\",\"CVP_XBLCK_B\":\"\",\"Y1E1KNB1M\":[{\"ZTERM_DES\":\"EndofMonth4%,Mid-Month2%\"}]}]},\"E1IDOCENHANCEMENT\":[{\"IDENTIFIER\":\"CFD_S_KNA1_IDOC_EX_1\",\"DATA\":\"91484293509C1FE097AD8B14E4BA1725<?xmlversion=\\\"1.0\\\"encoding=\\\"utf-16\\\"?><asx:abapxmlns:asx=\\\"http://www.sap.com/abapxml\\\"version=\\\"1.0\\\"><asx:values><KEY>OT1000</KEY><DATA><KNA1_EEW_CUST/><RULE_EXCLUSION/></DATA></asx:values></asx:abap>\"},{\"IDENTIFIER\":\"CFD_S_KNB1_IDOC_EX_1\",\"DATA\":\"91484293509C1FE097AD8B14E4BA3725<?xmlversion=\\\"1.0\\\"encoding=\\\"utf-16\\\"?><asx:abapxmlns:asx=\\\"http://www.sap.com/abapxml\\\"version=\\\"1.0\\\"><asx:values><KEY><KUNNR>OT1000</KUNNR><BUKRS>OT</BUKRS></KEY><DATA><KNB1_EEW_CC/></DATA></asx:values></asx:abap>\"},{\"IDENTIFIER\":\"CFD_S_KNVV_IDOC_EX_1\",\"DATA\":\"91484293509C1FE097AD8B14E4BA5725<?xmlversion=\\\"1.0\\\"encoding=\\\"utf-16\\\"?><asx:abapxmlns:asx=\\\"http://www.sap.com/abapxml\\\"version=\\\"1.0\\\"><asx:values><KEY><KUNNR>OT1000</KUNNR><VKORG>1700</VKORG><VTWEG>10</VTWEG><SPART>00</SPART></KEY><DATA><KNVV_EEW_CONTACT/><STATUS_OBJ_GUID/><BILLPLAN_PROC/></DATA></asx:values></asx:abap>\"}]}";
        processingService.processRecord(kafkaMessage);
    }

    @Test
    public void processRecords2() throws JsonProcessingException {
        setObject();
        MasterData  materialMasterData= new MasterData();
        E1KNA1M e1KNA1M= new E1KNA1M();
        materialMasterData.setE1KNA1M(e1KNA1M);

        processingService.processRecord(new ObjectMapper().writeValueAsString(materialMasterData));
    }

    @Test
    void testProcessRecord_ValidJsonButNoSupplierSaved() throws JsonProcessingException {
        // Arrange
        String validJsonWithNoSave = "{ \"e1Maram\": { \"ktokk\": \"OTHER\", \"lifnr\": \"12345\", \"name1\": \"Supplier Name\" } }";
        // Act
        processingService.processRecord(validJsonWithNoSave);
    }
}
