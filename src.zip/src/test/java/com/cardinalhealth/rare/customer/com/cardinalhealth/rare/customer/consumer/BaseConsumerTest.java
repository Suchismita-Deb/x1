package com.cardinalhealth.rare.customer.com.cardinalhealth.rare.customer.consumer;
import com.cardinalhealth.rare.customer.consumer.BaseConsumer;
import com.cardinalhealth.rare.customer.service.impl.ProcessingServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.serializer.DeserializationException;

import java.text.ParseException;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith({MockitoExtension.class, OutputCaptureExtension.class})
public class BaseConsumerTest {

    @InjectMocks
    BaseConsumer baseConsumer;

    @Mock
    ProcessingServiceImpl processingService;

    private final String payload = "{\"key\": \"value\"}";

    @BeforeEach
    public void setup() {

    }

    @Test
    public void consume_expectEventToProcess_whenValidMessageArrives(CapturedOutput output) throws JsonProcessingException {
        String topic = "test-topic";
        ConsumerRecord<String, String> record = new ConsumerRecord<>(topic, 0, 1, "key-0", payload);
        doNothing().when(processingService).processRecord(anyString());
        baseConsumer.consume(record, mock(Acknowledgment.class), 1);
        assertTrue(output.getOut().contains("key-0"));
    }

    @Test
    public void consume_expectRetryableException_whenNullObjectIsProvided() throws JsonProcessingException {
        String topic = "test-topic";
        ConsumerRecord<String, String> record = new ConsumerRecord<>(topic, 0, 1, "key-0", payload);
        String exceptionError = "Exception occurred: RuntimeException during unit test: consume_expectException_whenNullObjectIsProvided";
        doThrow(new RuntimeException(exceptionError)).when(processingService).processRecord(anyString());

        RuntimeException thrown = assertThrows(RuntimeException.class, () -> baseConsumer.consume(record, mock(Acknowledgment.class), 1));

        Assertions.assertEquals("Exception occurred: RuntimeException during unit test: consume_expectException_whenNullObjectIsProvided",
                thrown.getMessage());
    }

    @Test
    public void consume_expectNonRetryableException_whenNullObjectIsProvided() throws JsonProcessingException {
        String topic = "test-topic";
        ConsumerRecord<String, String> record = new ConsumerRecord<>(topic, 0, 1, "key-0", payload);
        doThrow(mock(DeserializationException.class)).when(processingService).processRecord(any());

        DeserializationException thrown = assertThrows(DeserializationException.class, () -> baseConsumer.consume(record, mock(Acknowledgment.class), 1));

        Assertions.assertNotNull(thrown);
    }
}
